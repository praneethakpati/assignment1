const { $ } = require('@wdio/globals')
const Page = require('./page');
const testData = require('../testData/Data.json')

class LoginPage extends Page {
   
    get inputCurrentAge () {
        return $('#current-age');
    }

    get inputRetirementAge () {
        return $('#retirement-age');
    }

    get inputCurrentAnnualIncome () {
        return $('#current-income');
    }

    get inputSpouseIncome () {
        return $('#spouse-income');
    }

    get inputRetirementSavings () {
        return $('#current-total-savings');
    }

    get inputRetirementContribution () {
        return $('#current-annual-savings');
    }

    get inputRetirementContributionIncrease () {
        return $('#savings-increase-rate');
    }

    get inputSocialSecurityIncome () {
        return $('label[for="yes-social-benefits"]');
    }

    get inputRelationshipStatus () {
        return $('label[for="married"]');
    }

    get inputSocialSecurityOverride () {
        return $('#social-security-override');
    }

    get btnSubmit () {
        return $('//button[normalize-space()="Calculate"]');
    }

    get resultMessage(){
        return $('#result-message')
    }

    get resultChart(){
        return $('#results-chart')
    }

    get resultEditInfo(){
        return $('[onclick="navigateToRetirementForm();"]')
    }

    get adjustDefaultValue(){
        return $('//a[normalize-space()="Adjust default values"]')
    }

    get defaultCalculaterModel(){
        return $('#default-values-modal-title')
    }

    get additionalIncome(){
        return $('//input[@id="additional-income"]')
    }

    get retirementYearsPlan(){
        return $('//input[@id="retirement-duration"]')
    }

    get postRetirementIncome(){
        return $('//label[@for="include-inflation"]')
    }

    get saveChangesButton(){
        return $('//button[normalize-space()="Save changes"]')
    }

    async formFilling () {

        await this.inputCurrentAge.setValue(testData.currentAge);
        await this.inputRetirementAge.setValue(testData.retirementAge);

        await browser.waitUntil(async () => {
            return await this.inputCurrentAnnualIncome.isDisplayed();
        });
        await this.inputCurrentAnnualIncome.click();
        await this.inputCurrentAnnualIncome.addValue(testData.currentAnnualIncome);
        await this.inputSpouseIncome.click();
        await  this.inputSpouseIncome.addValue(testData.spouseAnnualIncome);

        await this.inputRetirementSavings.click();
        await this.inputRetirementSavings.addValue(testData.currentRetirementSavings);
        await this.inputRetirementContribution.setValue(testData.currentRetirementContribution);

        await this.inputRetirementContributionIncrease.setValue(testData.annualRetirementContributionIncrease);
        await this.inputSocialSecurityIncome.click();
    
        await browser.waitUntil(async () => {
            return await this.inputRelationshipStatus.isClickable();
        });
        await this.inputRelationshipStatus.click();
        await this.inputSocialSecurityOverride.click();
        await this.inputSocialSecurityOverride.addValue(testData.socialSecurityOverride);

    }

    async resultMessageValidation(){
        await browser.waitUntil(async () => {
            return await this.resultMessage.isDisplayed();
        });
        await expect(this.resultMessage).toExist();
        const elementText = await this.resultMessage.getText();
        expect(elementText).toHaveValueContaining('Congratulations!')
        
    }

    async resultChartValidation(){
        await expect(this.resultChart).toExist();
    }

    async resultEditInfoValidation(){
        await expect(this.resultEditInfo).toExist();
    }

    async adjustDefaultValues(){
        await this.adjustDefaultValue.click();
        await browser.waitUntil(async () => {
            return await this.defaultCalculaterModel.isDisplayed();
        });
        await expect(this.defaultCalculaterModel).toExist();
        await this.additionalIncome.click();
        await this.additionalIncome.addValue(testData.additionalIncome);
        await this.retirementYearsPlan.setValue(testData.retirementYears);
        await this.postRetirementIncome.click();
        await this.saveChangesButton.click();
    }

    async submittCalculateButton(){
        await browser.waitUntil(async () => {
            return await this.btnSubmit.isDisplayed();
        });
        await expect(this.btnSubmit).toExist();
        // await browser.pause(3000)
        await this.btnSubmit.click();
    }

    open () {
        return super.open('login');
    }
}

module.exports = new LoginPage();
