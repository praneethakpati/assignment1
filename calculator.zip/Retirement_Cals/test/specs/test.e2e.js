const { expect } = require('@wdio/globals')
const LoginPage = require('../pageobjects/login.page')
const SecurePage = require('../pageobjects/secure.page')

describe('My Retirement Plan', () => {

    it('should enter retirement detail and calculate', async () => {

        await LoginPage.open()
        await LoginPage.formFilling();
        await LoginPage.adjustDefaultValues();
        await LoginPage.submittCalculateButton();
        await LoginPage.resultMessageValidation();
        await LoginPage.resultChartValidation();
        await LoginPage.resultEditInfoValidation();

    })
})

